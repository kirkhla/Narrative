import './App.css';
import MenuBar from './MenuBar';

export default function App() {
  return (
    <div>
<MenuBar />
</div>
  );
}


