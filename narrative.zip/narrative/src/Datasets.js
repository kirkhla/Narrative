import React, { useState ,useEffect} from 'react'
import { Header, Item ,Dropdown} from 'semantic-ui-react';
import { client } from './api';


export default function Datasets(){

    const [datasets,setDatasets] = useState('');
    const [countries,setCountries] = useState([]);
    const [options,setOptions] = useState([]);
    const [selected,setSelected] = useState([]);


      useEffect(() => {
        setOptions(countries.map(country => {
            return {key:country.name,
                    text:country.name,
                    value:country.countryCode}
                }))
     }, [countries]);

    useEffect(() => {
        client.get('datasets').then((response) => {
            setDatasets(response.data);
         });
     }, []);

     useEffect(() => {
        client.get('countries').then((response) => {
            setCountries(response.data);
         });
     }, []);

    return( 
      <div>
      <Header size='large' textAlign='center'>Datasets</Header>
      <Dropdown placeholder='Countries' fluid multiple selection options={options} onChange={(e, { value }) => setSelected(value)} />
     
      {datasets.length > 0 && datasets.map(dataset =><Item.Group>
    <Item key={dataset.id}>
       
      <Item.Image size='tiny' src={dataset.thumbnailUrl} />

      <Item.Content>
        <Item.Header as='h2'>{dataset.label}</Item.Header>
        <Item.Meta>Dataset Description</Item.Meta>
        <Item.Description>
          {dataset.description}
        </Item.Description>
        <Item.Extra>Cost Per Record: {dataset.costPerRecord}</Item.Extra>
        <Item.Extra>Available Records: {10500}</Item.Extra>
      </Item.Content>

    </Item>
   
  </Item.Group>
 )}
  
     
      
    </div>

      )

    }