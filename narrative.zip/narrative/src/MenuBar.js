import React, { useState} from 'react'
import { Menu, Segment } from 'semantic-ui-react';
import BuyOrders from './BuyOrders';
import Datasets from './Datasets';



export default function MenuBar(){
  const [activeItem,setActiveItem] = useState('Buy Orders')
  const handleItemClick = (e, { name }) => {setActiveItem(name);};
  return(<div>
      <Segment inverted>
        <Menu inverted pointing secondary>
          <Menu.Item
            name='Buy Orders'
            active={activeItem === 'Buy Orders'}
            onClick={handleItemClick}
          />
          <Menu.Item
            name='Datasets'
            active={activeItem === 'Datasets'}
            onClick={handleItemClick}
          /> 
        </Menu>
      </Segment>
    {activeItem === 'Buy Orders' &&<BuyOrders/>}
    {activeItem === 'Datasets' && <Datasets />}
    </div>
    );

   
  
}

