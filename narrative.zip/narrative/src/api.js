import axios from "axios";

export const client = axios.create({
   baseURL: "https://636accc9c07d8f936da7b368.mockapi.io/maritime/" 
});

   






