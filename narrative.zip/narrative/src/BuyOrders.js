import React, { useState, useEffect } from "react";
import {
  Header,
  Table,
  Button,
  Modal,
  Form,
  Item,
  Dropdown,
  Checkbox,
} from "semantic-ui-react";
import { client } from "./api";

export default function BuyOrders() {
  const [open, setOpen] = useState(false);
  const [orderName, setOrderName] = useState("");
  const [orderBudget, setOrderBudget] = useState("");
  const [datasets, setDatasets] = useState([]);
  const [date,setDate] = useState(new Date().toISOString().slice(0, 10));
  const [buyOrder,setBuyOrder] = useState('');

    const [countries,setCountries] = useState([]);
    const [options,setOptions] = useState([]);
    const [selected,setSelected] = useState([]);
    const [datasetIDs,setDatasetIDs] = useState([]);
    const [edit,setEdit] = useState(false);
    const [posted,setPosted] = useState(false);
    const [updated,setUpdated] = useState(false);
    const [deleted,setDeleted] = useState(false);
    const [orderDetails,setOrderDetails] = useState('');
    const [ID,setID] = useState('');
    const [details,setDetails] = useState(false);


    useEffect(() => {
        client.get('buy-orders').then((response) => {
            setBuyOrder(response.data);
         });
     }, []);

     useEffect(() => {
       if (!open) {
        setPosted(false);
        setOrderName('');
        setOrderBudget('');
        setDatasetIDs([]);
        setSelected([]);
       }
     }, [open]);


      useEffect(() => {
        setOptions(countries.map(country => {
            return {key:country.name,
                    text:country.name,
                    value:country.countryCode}
                }))
     }, [countries]);

    useEffect(() => {
        client.get('datasets').then((response) => {
            setDatasets(response.data);
         });
     }, []);

     useEffect(() => {
        client.get('countries').then((response) => {
            setCountries(response.data);
         });
     }, []);
//
     useEffect(() => {
        client.get(`buy-orders/${ID}`).then((response) => {
            setOrderDetails(response.data);
         });
     }, [ID]);

     useEffect(() => {
        if(updated) {
        client.put(`buy-orders/${ID}`,{
            id: ID,
            name: orderName,
            createdAt: date,
            datasetIds: datasetIDs,
            countries: selected,
            budget: orderBudget,
        }).then((response) => {
            setOrderDetails(response.data);
         });
        }
     }, [ID,orderName,selected,orderBudget,datasetIDs,date,updated]);

     useEffect(() => {
        if(deleted) {
        client.delete(`buy-orders/${ID}`).then((response) => {
            console.log('Deleted',response)
         });
        }
     }, [ID,deleted]);

  useEffect(() => {

    if(posted){
    client.post("buy-orders", {
      id: Math.random().toString(16).slice(2),
      name: orderName,
      createdAt: date,
      datasetIds: datasetIDs,
      countries: selected,
      budget: orderBudget,
    }).then(response => console.log('POSTED',response))
    .catch(error =>  console.error('There was an error!', error))
}
  }, [orderName,selected,orderBudget,datasetIDs,date,posted]);

  const addOrRemove = (name) => {
    const newIDs = [...datasetIDs];
    const index = newIDs.indexOf(name);
    if (index === -1) {
        newIDs.push(name);
    } else {
        newIDs.splice(index, 1);
    }
    setDatasetIDs(newIDs);
    
  }
  

  return (
    <div>
      <Header size="large" textAlign="center">
        Your Buy Orders
      </Header>

      <Header size="small">
        Showing 228 results from Canada
      </Header>

      <Modal
        onClose={() => setOpen(false)}
        onOpen={() => setOpen(true)}
        open={open}
        trigger={
          <Button fluid positive>
            Create New Buy Order
          </Button>
        }
      >
        <Modal.Header>New Buy Order</Modal.Header>
        <Modal.Content>
          <Form>
            <Form.Input
              label="Order name"
              type="text"
              onChange={(e, { value }) => setOrderName(value)}
            />
            <Form.Input
              label="Order budget"
              type="text"
              onChange={(e, { value }) => setOrderBudget(parseFloat(value))}
            />
            <Form.Field>
              <label>Forecasted Records</label>
            </Form.Field>
            <Form.Field>
              <label>Included datasets</label>
              {datasets.length > 0 && datasets.map(dataset =><Item.Group>
    <Item key={dataset.id}>
      <Item.Image size='tiny' src={dataset.thumbnailUrl} />
      <Item.Content>
        <Item.Header as='h2'>{dataset.label}</Item.Header>
        <Item.Extra>Cost Per Record: {dataset.costPerRecord}</Item.Extra>
        <Checkbox label='Select Dataset' 
        name={dataset.id.toString()}
        onChange={(e, { name }) => addOrRemove(name)}/>
      </Item.Content>

    </Item>
   
  </Item.Group>
 )}
            </Form.Field>
            <Form.Field>
              <label>Included countries</label>
              <Dropdown placeholder='Included Countries' fluid multiple selection options={options} onChange={(e, { value }) => setSelected(value)} />
            </Form.Field>
          </Form>
        </Modal.Content>
        <Modal.Actions>
          <Button color="green" onClick={() =>{ setOpen(false);setPosted(true);}}>
            Create Order
          </Button>
        </Modal.Actions>
      </Modal>
      <Table celled>
        <Table.Body>
             {buyOrder.length > 0 &&buyOrder.map(order => <Table.Row onClick={() => {setID(order.id);}}>
           
           <Table.Cell><label><b>Order Name</b></label><br/>{order.name}</Table.Cell>
          
           <Table.Cell> <label><b>Order Date</b></label><br/>{order.createdAt}</Table.Cell>
          
           <Table.Cell> <label><b>Forecasted Records</b></label><br/>{10500}</Table.Cell>
         </Table.Row>)}
          
          
        </Table.Body>

        
      </Table>


      <Modal
        onClose={() => setEdit(false)}
        onOpen={() => setEdit(true)}
        open={edit}

      >
        <Modal.Header>Edit Buy Order</Modal.Header>
        <Modal.Content>
          <Form>
            <Form.Input
              label="Order name"
              type="text"
              onChange={(e, { value }) => setOrderName(value)}
              value={orderName}
            />
            <Form.Input
              label="Order budget"
              type="number"
              onChange={(e, { value }) => setOrderBudget(value)}
              value={orderBudget}
            />
            <Form.Field>
              <label>Forecasted Records</label>
            </Form.Field>
            <Form.Field>
              <label>Included datasets</label>
              {datasets.length > 0 && datasets.map(dataset =><Item.Group>
    <Item key={dataset.id}>
      <Item.Image size='tiny' src={dataset.thumbnailUrl} />
      <Item.Content>
        <Item.Header as='h2'>{dataset.label}</Item.Header>
        <Item.Extra>Cost Per Record: {dataset.costPerRecord}</Item.Extra>
        <Checkbox label='Select Dataset' 
        name={dataset.id.toString()}
        onChange={(e, { name }) => addOrRemove(name)}/>
      </Item.Content>

    </Item>
   
  </Item.Group>
 )}
            </Form.Field>
            <Form.Field>
              <label>Included countries</label>
              <Dropdown placeholder='Included Countries' fluid multiple selection options={options} onChange={(e, { value }) => setSelected(value)} />
            </Form.Field>
          </Form>
        </Modal.Content>
        <Modal.Actions>
          <Button color="green" onClick={() => {setEdit(false); setUpdated(true)}}>
            Save
          </Button>
          
        </Modal.Actions>
      </Modal>
      <Modal
        onClose={() => {setDetails(false);setID('')}}
        onOpen={() => setDetails(true)}
        open={ID}
        
      >
        <Modal.Header>Buy Order Details</Modal.Header>
        <Modal.Content>
          <Form>
            <Form.Input
              label="Order name"
              type="text"
              onChange={(e, { value }) => setOrderName(value)}
              value={orderDetails.name}
              readonly
            />
            <Form.Input
              label="Order budget"
              type="number"
              onChange={(e, { value }) => setOrderBudget(value)}
              value={orderDetails.budget}
              readonly
            />
            <Form.Input
              label="Date Created"
              type="text"
              onChange={(e, { value }) => setOrderBudget(value)}
              value={orderDetails.createdAt}
              readonly
            />
            <Form.Field>
              <label>Forecasted Records</label>
            </Form.Field>
            <Form.Field>
              <label>Included datasets</label>
              {datasets.length > 0 && datasets.map(dataset =><Item.Group>
    <Item readonly key={dataset.id}>
      <Item.Image size='tiny' src={dataset.thumbnailUrl} />
      <Item.Content>
        <Item.Header as='h2'>{dataset.label}</Item.Header>
        <Item.Extra>Cost Per Record: {dataset.costPerRecord}</Item.Extra>
        <Checkbox label='Select Dataset' 
        name={dataset.id.toString()}
        onChange={(e, { name }) => addOrRemove(name)}/>
      </Item.Content>

    </Item>
   
  </Item.Group>
 )}
            </Form.Field>
            <Form.Field>
              <label>Included countries</label>
              <Dropdown placeholder='Included Countries' fluid multiple selection options={options} onChange={(e, { value }) => setSelected(value)} />
            </Form.Field>
          </Form>
        </Modal.Content>
        <Modal.Actions>
        <Button color="green" onClick={() => setEdit(true)}>
            Edit Order
          </Button>
          <Button color="red" onClick={() => {setDeleted(true);setID('')}}>
           Delete Order
          </Button>
        </Modal.Actions>
      </Modal>
    </div>
  );
}
